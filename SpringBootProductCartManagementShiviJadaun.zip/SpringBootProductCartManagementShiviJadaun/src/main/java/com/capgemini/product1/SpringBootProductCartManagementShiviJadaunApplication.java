package com.capgemini.product1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.capgemini.product1")
@EntityScan("com.capgemini.product1.bean")
public class SpringBootProductCartManagementShiviJadaunApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProductCartManagementShiviJadaunApplication.class, args);
	}

}
