package com.capgemini.product1.bean;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;


@Entity                                      
@Table(name = "Product")             //Giving table name is product        
public class Product {
	
   // Applying Validations on the given atrributes 
	
	@Pattern(regexp = "[a-zA-Z]{1}[0-9]{1,2}", message = "ID is not valid, id must start from an alphabet")  //writting pattern for the id
	@Id                                             //setting id as primary key
	private String id;


	@NotNull(message = "Product name can not be Null")                   //field cannot be null
	@Size(min = 3, max = 15, message = "Product Name is not valid, name length must be in between 3 to 15")
	private String name;
	
	@NotNull(message = "model can not be null")                            //field cannot be null
	@Size(min = 1,  max = 10, message = "model is not valid, name length must be in between 1 to 10")
	private String model;
	
	@NotNull(message = "price of a product cannot be null")                  //field cannot be null
	@Positive(message = "Enter price must be positive")
	private int price;

	//Generating getter and setter methods

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
}
