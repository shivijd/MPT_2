package com.capgemini.product1.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.product1.bean.Product;
import com.capgemini.product1.exception.ProductIdDoestNotExist;

@Repository
public interface IProductRepo {
	
	public Product createProduct(Product product);

	public Product updateProduct(Product product,String id) throws ProductIdDoestNotExist;

	public Product deleteProduct(String id) throws ProductIdDoestNotExist;

	public List<Product> viewProducts();

	public Product findProduct(String id) throws ProductIdDoestNotExist;

}
