package com.capgemini.product1.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.product1.bean.Product;
import com.capgemini.product1.exception.ProductIdDoestNotExist;

@Transactional                   //It is for whatever transactions we begin or commit, if the logic is correct is works properly else it rollbacks
@Repository                     
public class ProductRepoImpl implements IProductRepo {

	@PersistenceContext                //We use persistence context because we need entity manager, and entitymanager can be retrieve by persistence class
	EntityManager entitymanager;      

	@Override                                   
	public Product createProduct(Product product) {
		entitymanager.persist(product);               //Here persist means saving the data 
		entitymanager.flush();                        //And to commit those changes, like here we are saving data we use flush
		return product;                              //returning product
	}

	@Override
	public Product updateProduct(Product product, String id) throws ProductIdDoestNotExist {
		product = entitymanager.find(Product.class, id);                          //It basically search or find int the product class using (classname,primary key)
		if (product == null)
			throw new ProductIdDoestNotExist("ProductId Does not exist Exception");//if product not found
		entitymanager.merge(product);
		entitymanager.flush();
		return product;
	}

	@Override
	public Product deleteProduct(String id) throws ProductIdDoestNotExist {
		Product product = entitymanager.find(Product.class, id);
		if (product == null)
			throw new ProductIdDoestNotExist("Product Id DoesNot Exist");
		entitymanager.remove(product);                          //removing data from databse
		entitymanager.flush();                                 
		return product;
	}

	@Override
	public List<Product> viewProducts() {
		TypedQuery<Product> query = entitymanager.createQuery("select product from Product product", Product.class);//from this query we are retrieving all the values from database
		List<Product> list = query.getResultList(); //and after retrieval we will store the result in list using getResultSet
		return list;

	}

	@Override
	public Product findProduct(String id) throws ProductIdDoestNotExist {
		Product product = entitymanager.find(Product.class, id);
		if (product == null)
			throw new ProductIdDoestNotExist("Product does not exist");
	                         
		return product;
	}

}
