package com.capgemini.product1.exception;

public class ProductIdDoestNotExist extends Exception {
  public ProductIdDoestNotExist(String message)
  {
	  super(message);
  }
}
