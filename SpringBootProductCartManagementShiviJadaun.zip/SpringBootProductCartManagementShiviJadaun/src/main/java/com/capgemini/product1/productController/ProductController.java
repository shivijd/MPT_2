package com.capgemini.product1.productController;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.product1.bean.Product;
import com.capgemini.product1.exception.ProductIdDoestNotExist;
import com.capgemini.product1.service.IProductService;

@RestController     
public class ProductController {
	@Autowired
	IProductService iservice;
	
	@PostMapping(value="/addProduct")          //Giving URL  that we pass in postman
	public Product createProduct(@Valid @RequestBody Product product)//Valid applies validation to the product whatever we done in bean class
	{
		return iservice.createProduct(product);
	}
	@PutMapping(value="/updateProduct/{id}")           //Giving URL  that we pass in postman
	public Product updateProduct(@Valid @RequestBody Product product,@PathVariable String id) throws ProductIdDoestNotExist
	{
		return iservice.updateProduct(product,id);
	}
    @DeleteMapping(value="/deleteProduct/{id}")             //Giving URL  that we pass in postman
    public Product deleteProduct(@Valid @PathVariable String id) throws ProductIdDoestNotExist
    {
    	return iservice.deleteProduct(id);
    }
    @GetMapping(value="/viewProduct")                       //Giving URL  that we pass in postman
    public List<Product> viewProduct()
    {
    	return iservice.viewProducts();
    }
    @GetMapping(value="/findProduct/{id}")                        //Giving URL  that we pass in postman
    public Product findProduct(@Valid @PathVariable String id) throws ProductIdDoestNotExist
    {
    	return iservice.findProduct(id);
    }
}
