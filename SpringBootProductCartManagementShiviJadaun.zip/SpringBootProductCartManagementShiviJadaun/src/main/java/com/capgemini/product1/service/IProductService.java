package com.capgemini.product1.service;

import java.util.List;

import com.capgemini.product1.bean.Product;
import com.capgemini.product1.exception.ProductIdDoestNotExist;

public interface IProductService {
	public Product createProduct(Product product);

	public Product updateProduct(Product product,String id) throws ProductIdDoestNotExist;

	public Product deleteProduct(String id) throws ProductIdDoestNotExist;

	public List<Product> viewProducts();

	public Product findProduct(String id) throws ProductIdDoestNotExist;

}
