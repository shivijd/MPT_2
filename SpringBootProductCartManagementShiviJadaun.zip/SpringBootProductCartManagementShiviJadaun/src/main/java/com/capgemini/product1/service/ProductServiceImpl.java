package com.capgemini.product1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.product1.bean.Product;
import com.capgemini.product1.dao.IProductRepo;
import com.capgemini.product1.exception.ProductIdDoestNotExist;

@Service                 
public class ProductServiceImpl implements IProductService {
	@Autowired                 //Autowired is used when we use any class reference and we don't want to create its object or some functionality
	IProductRepo idao;

	@Override
	public Product createProduct(Product product) {
		product = idao.createProduct(product);    //calling dao create method using dao reference
		return product;
	}

	@Override
	public Product updateProduct(Product product, String id) throws ProductIdDoestNotExist {
		product = idao.updateProduct(product, id);          //calling dao update method using dao reference
		return product;                  
	}

	@Override
	public Product deleteProduct(String id) throws ProductIdDoestNotExist {

		return idao.deleteProduct(id);                      //calling dao delete method using dao reference
	}

	@Override
	public List<Product> viewProducts() {

		return idao.viewProducts();                         //calling dao view method using dao reference
	}

	@Override
	public Product findProduct(String id) throws ProductIdDoestNotExist {
        Product product=idao.findProduct(id);
		return product;                        //calling dao find method using dao reference
	}

}
