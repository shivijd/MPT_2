package com.capgemini.crud.SERVICE;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.crud.Employee;

@Service
public class ServiceClass {
  private List<Employee> emp=new ArrayList<>();

public ServiceClass() {
	
	emp.add(new Employee("101", "Shivi", "Devloper", 20000));
	 emp.add(new Employee("102", "Shikha", "Monitor", 10000));
	 emp.add(new Employee("103", "Sarita", "Devops", 3000));
}

public List<Employee> getAllEmployee()
{
	return emp;
}
 
public Employee getEmployee(String empId)
{
	for(Employee e:emp)
	  if(e.getEmpId().equals(empId))
		  return e;
	return null;
}

public void updateEmployee(String empId, Employee employee) {
	for(int i=0;i<emp.size();i++)
	{		
		Employee t =emp.get(i);
		if(t.getEmpId().equals(empId))
		{
			emp.set(i, employee);
			return;
		}
	}
	
}
public void addEmployee(Employee employee)
{
	emp.add(employee);
}

public void deleteEmployee(String empId) {
	for(Employee e:emp)
		
	if(e.getEmpId().equals(empId))
		emp.remove(empId);
	
}

}
